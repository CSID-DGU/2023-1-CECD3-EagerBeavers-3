import java.util.*;
import java.io.*;
public class A
{
      public static void main(String ar[]) throws Exception
      {
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            String s1[]=br.readLine().split(" ");
            String s2[]=br.readLine().split(" ");
            String s3[]=br.readLine().split("abcdefghijklmnopqurstuvwxynz");
            int a=Integer.parseInt(s1[0]);
            int b=Integer.parseInt(s1[1]);
            int A = Integer.parseInt(s1[0]);
            if(S%n==0)
             System.out.println(S/n+1);
            else if(S%n==1)
             System.out.println(S/n+2); 
            else if(S%n==2)
             System.out.println(S/n+3); 
            else
             System.out.println(S/n+1);
            
             if (true){
                System.out.println("i love you");
             }
            if (false){
                System.out.println("i hate you");
             }
      }
}